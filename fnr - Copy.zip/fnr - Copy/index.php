<?php

session_start();

if(!isset($_SESSION['user'])) {
    header('location:login.php');
}

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>FnR Borrowing</title>

    <style>
      @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
      body {
        background-color: #3ded97;
        font-family: 'Roboto', sans-serif;
      }
      .center-content {
        text-align: center;
        margin-top: 5%;
      }
      .center-content img {
        max-width: 100%;
        height: auto;
      }
      h1, h2 {
        color: #fff;
        text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.5);
      }
      h1 {
        font-size: 3em;
        font-weight: 300;
      }
      h2 {
        font-size: 2.5em;
        font-weight: 300;
        margin-top: 20px;
      }
      .btn {
        border-radius: 50px;
        padding: 10px 20px;
        font-size: 1.2em;
        transition: background-color 0.3s, transform 0.3s;
      }
      .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
      }
      .btn-success {
        background-color: #28a745;
        border-color: #28a745;
      }
      .btn:hover {
        transform: scale(1.05);
      }
    </style>
  </head>
  <body>
    <div class="container center-content">
      <h1>Welcome To</h1>
      <img src="img/image.png" alt="Logo" class="img-fluid my-3" width="15%" height="20%">
      <h2>FnR Borrowing</h2>
      <div>
        <a href="login.php"><button type="button" class="btn btn-primary m-2">Login</button></a>
        <a href="register.php"><button type="button" class="btn btn-success m-2">Register</button></a>
      </div>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
