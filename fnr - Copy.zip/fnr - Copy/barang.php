<?php

use LDAP\Result;

include 'layout/header.php';
include 'koneksi.php';

?>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">MENU</div>
                    <a class="nav-link" href="user.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        User
                    </a>
                    <a class="nav-link" href="barang.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Goods
                    </a>
                    <a class="nav-link" href="peminjam.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Borrow
                    </a>
                    <a class="nav-link" href="stock.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Stock
                    </a>
                </div>
            </div>
        </nav>
    </div>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Dashboard 1</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">
                        <div class="card-header">
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                Add More
                            </button>

                            <!-- Modal -->
                            <form method="post" action="barang.php" enctype="multipart/form-data">
                                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Add More</h5>
                                            </div>
                                            <div class="container">
                                                <div class="modal-body">
                                                    <input type="text" name="barang" placeholder="Goods" class="form-control" required>
                                                    <br>
                                                    <input type="text" name="merk" placeholder="Brand" class="form-control" required>
                                                    <br>
                                                    <input type="number" name="stok" placeholder="Stock" class="form-control" required>
                                                    <br>
                                                    <input type="text" name="kondisi" placeholder="Condition" class="form-control" required>
                                                    <br>
                                                    <input type="file" name="gambar" class="form-control" required>
                                                    <br>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary" name="go">Go!</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <?php
                            if (isset($_POST['go'])) {
                                $jenis_barang = $_POST['barang'];
                                $merk = $_POST['merk'];
                                $stok = $_POST['stok'];
                                $kondisi = $_POST['kondisi'];
                                $gambar = $_FILES['gambar']['name'];

                                if ($gambar != "") {
                                    $ekstensi_boleh = array('png', 'jpg');
                                    $x = explode('.', $gambar);
                                    $ekstensi = strtolower(end($x));
                                    $file_tmp = $_FILES['gambar']['tmp_name'];
                                    $angka_acak = rand(1, 999);
                                    $nama_gambar_baru = $angka_acak . '-' . $gambar;

                                    if (in_array($ekstensi, $ekstensi_boleh) === true) {
                                        move_uploaded_file($file_tmp, 'gambar/' . $nama_gambar_baru);

                                        $query = "INSERT INTO goods (jenis_barang, merk, stok, kondisi, gambar_barang) VALUES ('$jenis_barang', '$merk', '$stok', '$kondisi', '$nama_gambar_baru')";
                                        $result = mysqli_query($koneksi, $query);

                                        if (!$result) {
                                            die("Query Error: " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
                                        } else {
                                            echo "<script>alert('Data added successfully');window.location='barang.php';</script>";
                                        }
                                    } else {
                                        echo "<script>alert('Extensions can only be png and jpg');window.location='barang.php';</script>";
                                    }
                                } else {
                                    $query = "INSERT INTO goods (jenis_barang, merk, stok, kondisi) VALUES ('$jenis_barang', '$merk', '$stok', '$kondisi')";
                                    $result = mysqli_query($koneksi, $query);

                                    if (!$result) {
                                        die("Query Error: " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
                                    } else {
                                        echo "<script>alert('Data added successfully');window.location='barang.php';</script>";
                                    }
                                }
                            }
                            ?>

                        </div>
                    </li>
                </ol>
                <div class="row">
                </div>
                <div class="row">
                </div>
                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        Goods Data
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Goods Type</th>
                                    <th>Brand</th>
                                    <th>Stock</th>
                                    <th>Condition</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM goods ORDER BY id_barang ASC";
                                $result = mysqli_query($koneksi, $query);

                                if (!$result) {
                                    die("Query Error: " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
                                }

                                $no = 1;
                                while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                    <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $row['jenis_barang']; ?></td>
                                        <td><?php echo $row['merk']; ?></td>
                                        <td><?php echo $row['stok']; ?></td>
                                        <td><?php echo $row['kondisi']; ?></td>
                                        <td>
                                            <img src="gambar/<?php echo $row['gambar_barang']; ?>" alt="<?php echo $row['jenis_barang']; ?>" >
                                        </td>
                                        <td>
                                            <a href="edit_produk.php?id=<?php echo $row['id_barang']; ?>" class="btn btn-success">Edit</a>
                                            <a href="hapus_barang.php?id=<?php echo $row['id_barang']; ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>

                                <?php
                                    $no++;
                                }
                                ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <?php

        include 'layout/footer.php'

        ?>