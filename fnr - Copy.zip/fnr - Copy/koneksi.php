<?php

$koneksi = mysqli_connect("localhost", "root", "", "borrow") or die ('database tidak terhubing');

?>